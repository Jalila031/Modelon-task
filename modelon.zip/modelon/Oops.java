import javax.swing.*;
import java.awt.Color;

class oop extends JFrame {

    public oop() {
        // Combined into one string - removed text1 (unused) and text2 (redundant)
        String text = "This program demonstrates oop concepts in Java";

        JLabel label = new JLabel(text);

        JPanel panel = new JPanel();
        panel.setBackground(Color.white);
        panel.add(label);

        getContentPane().add(panel);

        // Removed WindowListener - EXIT_ON_CLOSE already handles window closing
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("oop principles");
        setSize(400, 400);  // Frame size set to 400x400 as required
        // Removed pack() - it was overriding the setSize(400,400)
        setVisible(true);
    }

    public static void main(String[] args) {
        new oop();
    }
}