import org.junit.Test;
import static org.junit.Assert.*;


public class BMICalculatorTest {

    private final BMICalculator calculator = new BMICalculator();
    private final BMIModel model = new BMIModel();

    @Test
    public void testBMICalculation_ValidInputs() {
        // weight=70kg, height=1.75m => BMI = 70/(1.75*1.75) = 22.857...
        double bmi = calculator.calculate(70, 1.75);
        assertEquals(22.857, bmi, 0.01);
    }

    @Test
    public void testCategory_Underweight() {
        model.setWeight(40);
        model.setHeight(1.75);
        model.calculateBMI();
        assertEquals("Underweight", model.getCategory());
    }

    @Test
    public void testCategory_NormalWeight() {
        model.setWeight(70);
        model.setHeight(1.75);
        model.calculateBMI();
        assertEquals("Normal weight", model.getCategory());
    }

    @Test
    public void testCategory_Overweight() {
        model.setWeight(85);
        model.setHeight(1.75);
        model.calculateBMI();
        // BMI = 27.76 => Overweight
        assertEquals("Overweight", model.getCategory());
    }

    @Test
    public void testCategory_Obese() {
        model.setWeight(110);
        model.setHeight(1.75);
        model.calculateBMI();
        assertEquals("Obese", model.getCategory());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testZeroHeight_ThrowsException() {
        calculator.calculate(70, 0);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNegativeHeight_ThrowsException() {
        calculator.calculate(70, -1.5);
    }

    @Test
    public void testVeryLargeWeight() {
        double bmi = calculator.calculate(500, 1.75);
        assertTrue(bmi > 100);
        model.setWeight(500);
        model.setHeight(1.75);
        model.calculateBMI();
        assertEquals("Obese", model.getCategory());
    }


    @Test
    public void testBoundary_BMI_18_5() {
        model.setWeight(18.5);
        model.setHeight(1.0);
        model.calculateBMI();
        assertEquals(18.5, model.getBmi(), 0.001);
        assertEquals("Normal weight", model.getCategory()); // >= 18.5
    }


    @Test
    public void testBoundary_BMI_25_0() {
        model.setWeight(25.0);
        model.setHeight(1.0);
        model.calculateBMI();
        assertEquals(25.0, model.getBmi(), 0.001);
        assertEquals("Overweight", model.getCategory()); // >= 25.0
    }
}
