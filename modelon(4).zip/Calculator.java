
public abstract class Calculator {

    protected String calculatorName;

    public Calculator(String name) {
        this.calculatorName = name;
    }


    public abstract double calculate(double input1, double input2);


    public String getCalculatorName() {
        return calculatorName;
    }
}
