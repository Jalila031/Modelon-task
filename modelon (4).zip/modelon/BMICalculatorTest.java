import org.junit.Test;
import static org.junit.Assert.*;


public class BMICalculatorTest {

    private final BMICalculator calculator = new BMICalculator();
    private final BMIModel model = new BMIModel();

    // ---- Test 1: Normal BMI Calculation ----
    @Test
    public void testBMICalculation_ValidInputs() {
        // weight=70kg, height=1.75m => BMI = 70/(1.75*1.75) = 22.857...
        double bmi = calculator.calculate(70, 1.75);
        assertEquals(22.857, bmi, 0.01);
    }

    // ---- Test 2: Underweight Category ----
    @Test
    public void testCategory_Underweight() {
        model.setWeight(40);
        model.setHeight(1.75);
        model.calculateBMI();
        // BMI = 40/(1.75^2) = 13.06 => Underweight
        assertEquals("Underweight", model.getCategory());
    }

    // ---- Test 3: Normal Weight Category ----
    @Test
    public void testCategory_NormalWeight() {
        model.setWeight(70);
        model.setHeight(1.75);
        model.calculateBMI();
        // BMI = 22.86 => Normal weight
        assertEquals("Normal weight", model.getCategory());
    }

    // ---- Test 4: Overweight Category ----
    @Test
    public void testCategory_Overweight() {
        model.setWeight(85);
        model.setHeight(1.75);
        model.calculateBMI();
        // BMI = 27.76 => Overweight
        assertEquals("Overweight", model.getCategory());
    }

    // ---- Test 5: Obese Category ----
    @Test
    public void testCategory_Obese() {
        model.setWeight(110);
        model.setHeight(1.75);
        model.calculateBMI();
        // BMI = 35.92 => Obese
        assertEquals("Obese", model.getCategory());
    }

    // ---- Test 6: Zero Height — Exception ----
    @Test(expected = IllegalArgumentException.class)
    public void testZeroHeight_ThrowsException() {
        calculator.calculate(70, 0);
    }

    // ---- Test 7: Negative Height — Exception ----
    @Test(expected = IllegalArgumentException.class)
    public void testNegativeHeight_ThrowsException() {
        calculator.calculate(70, -1.5);
    }

    // ---- Test 8: Very Large Weight ----
    @Test
    public void testVeryLargeWeight() {
        double bmi = calculator.calculate(500, 1.75);
        // BMI = 500/(1.75^2) = 163.26
        assertTrue(bmi > 100);
        model.setWeight(500);
        model.setHeight(1.75);
        model.calculateBMI();
        assertEquals("Obese", model.getCategory());
    }


    @Test
    public void testBoundary_BMI_18_5() {
        // weight = 18.5 * (1.0)^2 = 18.5 kg at height 1.0m
        model.setWeight(18.5);
        model.setHeight(1.0);
        model.calculateBMI();
        assertEquals(18.5, model.getBmi(), 0.001);
        assertEquals("Normal weight", model.getCategory()); // >= 18.5
    }


    @Test
    public void testBoundary_BMI_25_0() {
        model.setWeight(25.0);
        model.setHeight(1.0);
        model.calculateBMI();
        assertEquals(25.0, model.getBmi(), 0.001);
        assertEquals("Overweight", model.getCategory()); // >= 25.0
    }
}
