
public class BMICalculator extends Calculator {

    public BMICalculator() {
        super("BMI Calculator");
    }


    @Override
    public double calculate(double weight, double height) {
        if (height <= 0) {
            throw new IllegalArgumentException("Height must be greater than 0");
        }
        return weight / (height * height);
    }
}