import javax.swing.*;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.BorderLayout;

class Close extends JFrame {

    public Close() {
        String text = "This program demonstrates oop concepts in Java";

        
        JLabel label = new JLabel(text);
        JPanel topPanel = new JPanel();
        topPanel.setBackground(Color.white);
        topPanel.add(label);

        
        JButton logoutButton = new JButton("Close");
        logoutButton.setFocusPainted(false);
        
        
        logoutButton.addActionListener(e -> {
            dispose();          
            System.exit(0);     
        });

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottomPanel.setBackground(Color.white);
        bottomPanel.add(logoutButton);

        
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Color.white);
        mainPanel.add(topPanel, BorderLayout.CENTER);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        getContentPane().add(mainPanel);

        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("oop principles");
        setSize(400, 400);
        setVisible(true);
    }

    public static void main(String[] args) {
        new Close();
    }
}