public class BMIModel {

    private double height; // in meters
    private double weight; // in kg
    private double bmi;

    public BMIModel() {
        this.height = 0;
        this.weight = 0;
        this.bmi = 0;
    }

 
    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public double getBmi() {
        return bmi;
    }


    public void calculateBMI() {
        if (height <= 0) {
            throw new IllegalArgumentException("Height must be greater than 0");
        }
        this.bmi = weight / (height * height);
    }


    public String getCategory() {
        if (bmi < 18.5) return "Underweight";
        else if (bmi < 25.0) return "Normal weight";
        else if (bmi < 30.0) return "Overweight";
        else return "Obese";
    }
}
