import javax.swing.*;
import java.awt.*;
class Application extends JFrame {

    private final BMIModel bmiModel;
    private final BMICalculator bmiCalculator;

    private JTextField heightField;
    private JTextField weightField;
    private JLabel resultLabel;
    private JLabel categoryLabel;

    public Application() {
        bmiModel = new BMIModel();
        bmiCalculator = new BMICalculator();  

        JLabel demoLabel = new JLabel("This program demonstrates oop concepts in Java");
        demoLabel.setFont(new Font("Arial", Font.BOLD, 14));

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        topPanel.setBackground(Color.white);
        topPanel.add(demoLabel);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.white);
        formPanel.setBorder(BorderFactory.createTitledBorder("BMI Calculator"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 5, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0;
        formPanel.add(new JLabel("Height (cm):"), gbc);
        gbc.gridx = 1; gbc.weightx = 1;
        heightField = new JTextField(10);
        formPanel.add(heightField, gbc);

        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0;
        formPanel.add(new JLabel("Weight (kg):"), gbc);
        gbc.gridx = 1; gbc.weightx = 1;
        weightField = new JTextField(10);
        formPanel.add(weightField, gbc);

        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        gbc.insets = new Insets(10, 10, 5, 10);
        JButton calcButton = new JButton("Calculate BMI");
        calcButton.setFocusPainted(false);
        calcButton.addActionListener(e -> calculateBMI());
        formPanel.add(calcButton, gbc);

        gbc.gridy = 3;
        gbc.insets = new Insets(5, 10, 2, 10);
        resultLabel = new JLabel("BMI: --");
        resultLabel.setFont(new Font("Arial", Font.BOLD, 13));
        formPanel.add(resultLabel, gbc);

        gbc.gridy = 4;
        categoryLabel = new JLabel("Category: --");
        categoryLabel.setFont(new Font("Arial", Font.PLAIN, 13));
        formPanel.add(categoryLabel, gbc);

        JButton closeButton = new JButton("Close");
        closeButton.setFocusPainted(false);
        closeButton.addActionListener(e -> {
            dispose();
            System.exit(0);
        });

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottomPanel.setBackground(Color.white);
        bottomPanel.add(closeButton);

        JPanel mainPanel = new JPanel(new BorderLayout(0, 10));
        mainPanel.setBackground(Color.white);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(formPanel, BorderLayout.CENTER);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        getContentPane().add(mainPanel);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("oop principles");
        setSize(400, 400);
        setVisible(true);
    }


    private void calculateBMI() {
        try {
            double heightCm = Double.parseDouble(heightField.getText().trim());
            double weightKg = Double.parseDouble(weightField.getText().trim());

            double heightM = heightCm / 100.0; // convert cm to meters

            double bmi = bmiCalculator.calculate(weightKg, heightM);

            bmiModel.setHeight(heightM);
            bmiModel.setWeight(weightKg);
            bmiModel.calculateBMI();

            resultLabel.setText(String.format("BMI: %.2f", bmi));
            categoryLabel.setText("Category: " + bmiModel.getCategory());

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers.",
                    "Input Error", JOptionPane.ERROR_MESSAGE);
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Validation Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Application());
    }
}
